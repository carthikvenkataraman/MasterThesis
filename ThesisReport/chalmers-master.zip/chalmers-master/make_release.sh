#!/usr/bin/sh
zip -r ChalmersLaTeXTemplates Example*.tex ExampleBib.bib *.sty *.cls figures/ README
